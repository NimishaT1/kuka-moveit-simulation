^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kuka_iontec_support
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.9.0 (2024-05-06)
------------------
* Add model for robot `kr70_r2100` (transform chain, joint limits, collision meshes)
* Contributors: Aron Svastits
